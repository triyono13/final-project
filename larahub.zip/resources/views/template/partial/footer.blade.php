        <!-- Footer Start -->
        <footer class="footer">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-6">
                        2018 - 2019 &copy; Simulor theme by <a href="">Coderthemes</a>
                    </div>
                    <div class="col-md-6">
                        <div class="text-md-right footer-links d-none d-sm-block">
                            <a href="#">About Us</a>
                            <a href="#">Help</a>
                            <a href="#">Contact Us</a>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- end Footer -->

        <script src="/assets/js/vendor.min.js"></script>
        
        <script src="/assets/libs/jquery-nice-select/jquery.nice-select.min.js"></script>
        <script src="/assets/libs/switchery/switchery.min.js"></script>
        <script src="/assets/libs/select2/select2.min.js"></script>
        <script src="/assets/libs/bootstrap-maxlength/bootstrap-maxlength.min.js"></script>
        <script src="/assets/libs/moment/moment.min.js"></script>
        <script src="/assets/libs/bootstrap-daterangepicker/daterangepicker.js"></script>
        <!-- Mask input -->
        <script src="/assets/libs/jquery-mask-plugin/jquery.mask.min.js"></script>

        <!-- App js -->
        <script src="/assets/js/app.min.js"></script>
        
        <!-- Init js-->
        <script src="/assets/js/pages/form-advanced.init.js"></script>
        </body>
</html>